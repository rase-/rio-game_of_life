####
The source files are under the src/ -directory separated in folders named after the packages of the class files.
Removing the package-separation, moving the sources to the root directory and rewriting the build scripts seemed
like an awful lot of pointless and unrelated work, so instead we're going with this.

####
