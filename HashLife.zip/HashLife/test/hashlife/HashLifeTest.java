/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hashlife;

import org.junit.*;
import static org.junit.Assert.*;

/**
 *
 * @author scolphoy
 */
public class HashLifeTest {
    
    public HashLifeTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class HashLife.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        HashLife.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of result method, of class HashLife.
     */
    @Test
    public void testResult() {
        System.out.println("result");
        MacroCell nw = null;
        MacroCell ne = null;
        MacroCell se = null;
        MacroCell sw = null;
        MacroCell expResult = null;
        MacroCell result = HashLife.result(nw, ne, se, sw);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
}
